import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ExamPapersComparison extends Application{
	File folder;
	static int flex = 10, lines=0;
	static Set<String> finalResult;
	@FXML
	Button start, browse;
	@FXML
	Spinner<Integer> flexibility;
	
	public static void main(String[] args) {
		launch(args);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage ps) {
		try{
		
		StackPane root = FXMLLoader.load(ExamPapersComparison.class.getResource("papersComparison.fxml"));
		root.getChildren().add(0, new ImageView(new Image(ExamPapersComparison.this.getClass().getResourceAsStream("/bg.jpg"))));
		start = (Button) root.lookup("#start");
		browse = (Button) root.lookup("#browse");
		flexibility = (Spinner<Integer>) root.lookup("#flexibility");
		Scene s = new Scene(root,450,325);
		ps.getIcons().add(new Image(ExamPapersComparison.class.getResourceAsStream("/icon.png")));
		ps.setResizable(false);
		ps.setTitle("Main Menu");
		ps.setScene(s);
		ps.show();
		} catch (Exception e) {
		e.printStackTrace();
		}
		
		browse.setOnAction(e->{
			DirectoryChooser dc = new DirectoryChooser();
			folder = dc.showDialog(null);
		});
		
	    SpinnerValueFactory<Integer> valueFactory =
	                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 30, 10);
	 
	    flexibility.setValueFactory(valueFactory);
	    
	    start.setOnAction(e->{
	    	flex = 31 - flexibility.getValue();
	    	ArrayList<ArrayList<String>> examPapers = new ArrayList<ArrayList<String>>();
			Scanner read = null;
			//////////////Read All Files/////////////////
			if(folder != null){
		      	File[] listOfFiles = folder.listFiles();
		      	for (File file : listOfFiles) {
		      		if (file.isFile()) {
		      			try {
								read=new Scanner(file);
								ArrayList<String> thePaper = new ArrayList<String>();
								while(read.hasNext()){
									String line = read.nextLine();
									if(!line.replace(" ", "").isEmpty()){
										thePaper.add(line);
									}
									
								}
								examPapers.add(thePaper);
								read.close();
							} catch (FileNotFoundException ex) {
								ex.printStackTrace();
							}
		      			
		      		}
		      	}
		      	FileChooser fileChooser = new FileChooser();
				FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
		        fileChooser.getExtensionFilters().add(extFilter);
		        File file = fileChooser.showSaveDialog(new Stage());
		          
		          if(file != null){
		        	  finalResult = new TreeSet<String>();
		        	  PrintWriter out = null;
		        	  try {
		  				out = new PrintWriter(file);
		  			} catch (IOException e1) {
		  				e1.printStackTrace();
		  			}
		        	// compare each two full papers
		        	for(int i=0; i<examPapers.size(); i++){
		      	        for(int j=i+1; j<examPapers.size(); j++){
		      	      		ArrayList<String> oneResult = compareTwoPapers(examPapers.get(i), examPapers.get(j));
		      	      		if(oneResult!=null){
		      	      		 
			      	      		for(int x=0; x<oneResult.size(); x++){
			      	      			finalResult.add(oneResult.get(x).trim());
			      	      			
			      	      		}
		      	      		}
			      	      		
		      	      	}
		      	     }
		        	for(String line : finalResult){
		        		out.println(line);
		        		lines++;
		        	}
		      	    out.close();
		      	    
		      	  Alert notification = new Alert(AlertType.INFORMATION);
		          notification.setTitle("Information");
		          notification.setHeaderText("Your Result Has Been Saved Successfully");
		          notification.setContentText("Done with " + lines + " lines!");
		          notification.setOnCloseRequest(ee->{
		        	  ps.close();
		          }); 
		          notification.showAndWait();
		          
		          }	      
		  }      
		    });	
   
	}

	/* This compares two papers line by line*/
	public static ArrayList<String> compareTwoPapers(ArrayList<String> first, ArrayList<String> second){
		ArrayList<String> similarity = new ArrayList<String>();
		for(int i=0; i<first.size(); i++){
			for(int j=0; j<second.size(); j++){
					String[] firstLine=first.get(i).split(" "); // take words to array
					String[] secondLine=second.get(j).split(" ");
					String similarIdea = compareTwoLines(firstLine, secondLine, flex); // comparing them at the words level
					if(similarIdea!=null){
						similarity.add(similarIdea);
					}
			}
		}
		if(!similarity.isEmpty()){
			return similarity;
		}
		return null;
	}
	
	public static String compareTwoLines(String[] firstLine, String[] secondLine, int accuracy){
		String fLine = "", sLine ="";
		for(int i=0; i<firstLine.length; i++){fLine+= firstLine[i] + " ";}
		for(int i=0; i<secondLine.length; i++){sLine+= secondLine[i] + " ";}
		
		int count =0;
		for(String word1 : firstLine){
			for(String word2 : secondLine){
				if(word1.equalsIgnoreCase(word2)){
					count++;
				}
			}
		}
		String result = (count>=accuracy)? fLine + "(" + sLine + ")" : null;
		
		return result;
		
	}
	
	
}
